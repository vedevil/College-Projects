Execute a.out file and for few inputs it runs perfectly(mentioned in test.txt file)

thank you!!!
